/**
 * Das Paket oop.mandelbrot enthält Klassen zur Erzeugung und Darstellung des Mandelbrot-Fraktals.
 * 
 * @author Aleksandar Travanov
 * @version 1.0
 */

package oop.mandelbrot;
